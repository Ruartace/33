import { createRouter, createWebHistory } from 'vue-router'
import PlaceholderView from '../views/PlaceholderView.vue'
import Patentincoming from '../views/Patentincoming/index.vue'
import Trademarkincoming from '../views/Trademarkincoming/index.vue'

const routes = [
  { path: '/', redirect: '/patent/electronic' },
  {
    path: '/patent/electronic',
    name: 'patent-electronic',
    component: Patentincoming,
    meta: { title: '专利电子来文' },
  },
  {
    path: '/patent/no-action',
    name: 'patent-no-action',
    component: PlaceholderView,
    meta: { title: '专利无需处理' },
  },
  {
    path: '/trademark/electronic',
    name: 'trademark-electronic',
    component: Trademarkincoming,
    meta: { title: '商标电子来文' },
  },
  {
    path: '/trademark/no-action',
    name: 'trademark-no-action',
    component: PlaceholderView,
    meta: { title: '商标无需处理' },
  },
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})

import { initIdFromUrl } from '@/utils/idStore'

// 路由层二次兜底：万一 main.js 里 initIdFromUrl 没被调用（比如 SSR / 特殊入口），
// 每次路由进入都再尝试把 URL 上的 userId 固化一下。
router.beforeEach((_to, _from, next) => {
  initIdFromUrl()
  next()
})

export default router
