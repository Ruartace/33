/**
 * 外部网站跳转进来文网站时，URL 上带 ?userId=xxx。
 * 本模块负责：落地即把 userId 固化到 localStorage，之后全站统一从 getId() 读取。
 *
 * —— 调用链 ——
 * main.js                initIdFromUrl()   入口第一时间固化（最优先）
 * router.beforeEach       initIdFromUrl()   任何路由进入再兜一次
 * App.vue onMounted      initIdFromUrl()   组件层再兜一次
 * 业务接口               getId()           只读，不关心最初从哪来
 */

const STORAGE_KEY = 'EXT_USER_ID'
const URL_PARAM   = 'userId'

// 内存缓存，避免每次请求都走 localStorage
let cache = null

/**
 * 从 URL 中提取 userId：
 *   - 有  → 写入 localStorage + 内存缓存，并可选从 URL 上移除
 *   - 无  → 不做事，保持现状
 * 这个函数可以被多处安全地重复调用（幂等）。
 */
export function initIdFromUrl() {
  try {
    const url = new URL(window.location.href)
    const idFromUrl = url.searchParams.get(URL_PARAM)
    if (idFromUrl) {
      localStorage.setItem(STORAGE_KEY, idFromUrl)
      cache = idFromUrl

      // 清掉 URL 上的 userId，避免被复制/分享泄露，也避免 beforeEach 重复触发
      url.searchParams.delete(URL_PARAM)
      window.history.replaceState({}, '', url.toString())
    }
  } catch (e) {
    // 隐私模式 / CSP 下 localStorage 可能抛错，降级为内存变量
    console.warn('[idStore] initIdFromUrl failed:', e)
  }
}

/**
 * 全站统一读 userId 的地方。
 * 优先返回内存缓存，其次 localStorage，最后兜底 route.query（如果调用方传了）。
 * @param {string} [fallback]  路由层传入的 route.query.userId，极短窗口期兜底用
 * @returns {string}
 */
export function getId(fallback) {
  if (cache) return cache
  try {
    cache = localStorage.getItem(STORAGE_KEY)
  } catch (e) {
    /* ignore */
  }
  if (cache) return cache
  if (fallback) {
    cache = String(fallback)
    // 兜底拿到后也写一次 localStorage，避免后续还在兜底
    try { localStorage.setItem(STORAGE_KEY, cache) } catch (e) { /* ignore */ }
  }
  return cache || ''
}

/** 清缓存（登出 / 切换用户时调） */
export function clearId() {
  cache = null
  try { localStorage.removeItem(STORAGE_KEY) } catch (e) { /* ignore */ }
}

/** 当前是否已有 userId */
export function hasId() {
  return !!getId()
}
